package com.tutorial.Main;

public enum ID {

	Player(),
	//Player2(),
	BasicEnemy(),
	FastEnemy(),
	SmartEnemy(),
	HardEnemy(),
	EnemyBoss(),
	MenuParticle(),
	Trail();
	
}
